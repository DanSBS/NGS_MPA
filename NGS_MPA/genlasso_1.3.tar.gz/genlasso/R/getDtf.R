getDtf <- function(n, ord) {
  return(as.matrix(getDtfSparse(n,ord)))
}
