getD1dSparse <- function(n) {
  return(getDtfSparse(n,0))
}
