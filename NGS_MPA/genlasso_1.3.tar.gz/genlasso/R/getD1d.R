getD1d <- function(n) {
  return(as.matrix(getD1dSparse(n)))
}
