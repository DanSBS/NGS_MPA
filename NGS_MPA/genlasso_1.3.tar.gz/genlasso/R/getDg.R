getDg <- function(graph) {
  return(as.matrix(getDgSparse(graph)))
}
