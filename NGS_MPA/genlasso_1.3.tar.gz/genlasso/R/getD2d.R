getD2d <- function(dim1, dim2) {
  return(as.matrix(getD2dSparse(dim1,dim2)))
}
