.onLoad <- function (libname, pkgname) {
  options(Matrix.quiet.qr.R = TRUE)
}
