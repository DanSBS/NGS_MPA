getDtfPos <- function(n,ord,pos) {
  return(as.matrix(getDtfPosSparse(n,ord,pos)))
}
